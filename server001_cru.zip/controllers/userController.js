const dbModels = require("../models/");

const user_index = (req, res) => {};

const user_create_post = (req, res) => {};

const user_details_get = (req, res) => {};

const user_update = (req, res) => {};

const users_delete = (req, res) => {};

module.exports = { users_get, user_details_get, user_update, users_delete };
